import React from 'react';
import { cva, cx } from 'class-variance-authority';

interface ButtonProps {
  variant?: 'primary' | 'success' | 'warning' | 'danger' | 'inverse' | 'purple';
  size?: 'small' | 'medium' | 'large' | 'extra-large';
  roundness?: 'square' | 'small' | 'base' | 'medium' | 'large' | 'xl' | '2xl' | 'circular';
  text: string;
}

const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 px-4 py-2 font-semibold ring-offset-white focus-visible:outline-none focus-visible:ring-2 disabled:opacity-50 disabled:pointer-events-none',
  {
    variants: {
      variant: {
        primary: 'bg-blue-600 hover:bg-blue-700 border border-transparent',
        success: 'bg-green-600 hover:bg-green-700 border border-transparent',
        warning: 'bg-yellow-600 hover:bg-yellow-700 border border-transparent',
        danger: 'bg-red-600 hover:bg-red-700 border border-transparent',
        inverse: 'bg-gray-800 hover:bg-gray-900 text-white border border-transparent',
        purple: 'bg-purple-600 hover:bg-purple-700 border border-transparent',
      },
      size: {
        small: 'text-xs py-1 px-2',
        medium: 'text-sm py-2 px-4',
        large: 'text-base py-3 px-6',
        'extra-large': 'text-lg py-4 px-8',
      },
      roundness: {
        square: 'rounded-none',
        small: 'rounded-sm',
        base: 'rounded-md',
        medium: 'rounded-lg',
        large: 'rounded-xl',
        xl: 'rounded-2xl',
        '2xl': 'rounded-3xl',
        circular: 'rounded-full',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'medium',
      roundness: 'base',
    },
  }
);

const Button: React.FC<ButtonProps> = ({ variant, size, roundness, text }) => {
  return (
    <button className={cx(buttonVariants({ variant, size, roundness }))}>
      {text} {/* Render the text prop */}
    </button>
  );
};

export default Button;
