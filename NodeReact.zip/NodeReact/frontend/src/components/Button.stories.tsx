import React from 'react';
import { Meta, StoryObj } from '@storybook/react';
import Button from './Button';

const meta: Meta<typeof Button> = {
  title: 'Components/Button',
  component: Button,
  parameters: {
    layout: 'centered',
  },
};

export default meta;

type Story = StoryObj<typeof Button>;

export const Primary: Story = {
  args: {
    variant: 'primary',
    size: 'medium',
    roundness: 'base',
    text: 'Click Me',
  },
};

export const Success: Story = {
  args: {
    variant: 'success',
    size: 'large',
    roundness: 'xl',
    text: 'Success',
  },
};

export const Warning: Story = {
  args: {
    variant: 'warning',
    size: 'small',
    roundness: 'small',
    text: 'Warning',
  },
};

export const Danger: Story = {
  args: {
    variant: 'danger',
    size: 'extra-large',
    roundness: '2xl',
    text: 'Delete',
  },
};

export const Inverse: Story = {
  args: {
    variant: 'inverse',
    size: 'medium',
    roundness: 'base',
    text: 'Cancel',
  },
};

export const Purple: Story = {
  args: {
    variant: 'purple',
    size: 'large',
    roundness: 'xl',
    text: 'Purple Button',
  },
};
