<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class CustomBoxModule extends Module
{
    public function __construct()
    {
        $this->name = 'customboxmodule';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Your Name';
        $this->need_instance = 0;
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Custom Box Module');
        $this->description = $this->l('Allows adding customizable boxes with images, titles, and links.');
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('displayHome') &&
            $this->installDb();
    }

    public function uninstall()
    {
        return parent::uninstall() && $this->uninstallDb();
    }

    private function installDb()
    {
        return Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'custom_boxes` (
            `id_custom_box` INT(11) AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(255) NOT NULL,
            `image` VARCHAR(255),
            `link` VARCHAR(255),
            `icon` VARCHAR(255)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;');
    }

    private function uninstallDb()
    {
        return Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'custom_boxes`;');
    }

    public function getContent()
    {
        return $this->displayForm();
    }

    private function displayForm()
    {
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->submit_action = 'submitCustomBoxModule';

        $helper->fields_value['CUSTOM_BOX_TITLE'] = Configuration::get('CUSTOM_BOX_TITLE');

        return $helper->generateForm([
            'form' => [
                'legend' => [
                    'title' => $this->l('Settings')
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('Box Title'),
                        'name' => 'CUSTOM_BOX_TITLE',
                        'size' => 20,
                        'required' => true
                    ]
                ],
                'submit' => ['title' => $this->l('Save')]
            ]
        ]);
    }

    public function hookDisplayHome($params)
    {
        $this->context->smarty->assign(
            'custom_boxes',
            Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'custom_boxes`')
        );
        return $this->display(__FILE__, 'custombox.tpl');
    }
}
